# qradar-ansible-workshop
 qradar-ansible-workshop
