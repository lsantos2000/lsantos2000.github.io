/bin/bash  datetime="$(date)"  echo "  Custom Action Script Test Time: $datetime" >> ~/test/test.txt  echo "Text written to /home/customactionuser/test.txt?"

